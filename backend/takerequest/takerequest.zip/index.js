const AWS = require('aws-sdk');
const nodemailer = require('nodemailer');

const secretsManager = new AWS.SecretsManager();
const sns = new AWS.SNS();

exports.handler = async (event, context) => {
  const { bookTitle, bookOwnerEmail, userEmail } = JSON.parse(event.body);

  try {
    // Fetch the email credentials from AWS Secrets Manager
    const secretName = 'smSecret'; // Replace with the name of your secret in Secrets Manager
    const secret = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
    const { email, password } = JSON.parse(secret.SecretString);

    // Create a transporter to send emails using SMTP
    const transporter = nodemailer.createTransport({
      service: 'Gmail', // Replace with your email service provider
      auth: {
        user: email, // Use the retrieved email address
        pass: password, // Use the retrieved email password or app password
      },
    });

    // Email message options
    const mailOptions = {
      from: email, // Use the retrieved email address
      to: bookOwnerEmail, // Email address of the book owner
      subject: 'Take Request for Book', // Email subject
      text: `User with email ${userEmail} is interested in taking your book "${bookTitle}".`, // Email body
    };

    // Send the email
    const info = await transporter.sendMail(mailOptions);

    console.log('Email sent:', info.response);

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Email sent successfully' }),
    };
  } catch (error) {
    console.error('Error sending email:', error);

    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error sending email' }),
    };
  }
};
