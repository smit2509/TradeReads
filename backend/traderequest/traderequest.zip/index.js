const AWS = require('aws-sdk');
const nodemailer = require('nodemailer');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();
const secretsManager = new AWS.SecretsManager();

const tableName = 'books'; // Update with your table name

exports.handler = async (event, context) => {
  const { bookId1, bookId2 } = JSON.parse(event.body);

  try {
    // Fetch the email credentials from AWS Secrets Manager
    const secretName = 'smSecret'; // Replace with the name of your secret in Secrets Manager
    const secret = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
    const { email, password } = JSON.parse(secret.SecretString);

    // Retrieve book details from DynamoDB for bookId1
    const params1 = {
      TableName: tableName,
      Key: { book_id: bookId1 },
    };

    const res1 = await dynamodb.get(params1).promise();
    const book1 = res1.Item;

    // Retrieve book details from DynamoDB for bookId2
    const params2 = {
      TableName: tableName,
      Key: { book_id: bookId2 },
    };

    const res2 = await dynamodb.get(params2).promise();
    const book2 = res2.Item;

    // Assuming you have access to book owner emails directly or can fetch them using book details
    const book1OwnerEmail = book1.book_owner; // Replace with the actual email for bookId1 owner
    const book2OwnerEmail = book2.book_owner; // Replace with the actual email for bookId2 owner

    // Create a transporter to send emails using SMTP
    const transporter = nodemailer.createTransport({
      service: 'Gmail', // Replace with your email service provider
      auth: {
        user: email, // Use the retrieved email address
        pass: password, // Use the retrieved email password or app password
      },
    });

    // Compose email message for book1 owner
    const mailOptions1 = {
      from: email, // Use the retrieved email address
      to: book1OwnerEmail, // Email address of the book1 owner
      subject: 'Trade Request for Your Book', // Email subject
      text: `User with email ${book2OwnerEmail} is interested in trading their book "${book2.title}" with your book "${book1.title}". Here are the details of the book they are offering:\n\nTitle: ${book2.title}\nAuthor: ${book2.author}\nGenre: ${book2.genre}\nRelease Year: ${book2.release_year}\nDescription: ${book2.description}`, // Email body
    };

    // Send the emails
    await transporter.sendMail(mailOptions1);
    console.log('Emails sent successfully');
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Trade request emails sent successfully' }),
    };
  } catch (error) {
    console.error('Error sending email:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Error sending email' }),
    };
  }
};
