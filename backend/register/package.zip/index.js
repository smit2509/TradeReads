const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');

// AWS SDK configuration
AWS.config.update({ region: 'us-east-1' }); // Update with your desired region

// Create DynamoDB instance
const dynamodb = new AWS.DynamoDB.DocumentClient();

// Example DynamoDB table name
const tableName = 'users'; // Update with your table name

exports.handler = async (event, context, callback) => {
  const { username, email, password } = JSON.parse(event.body);

  try {
    // Check if user already exists
    const params = {
      TableName: tableName,
      Key: { email },
    };

    const data = await dynamodb.get(params).promise();

    if (data.Item) {
      return callback(null, {
        statusCode: 409,
        body: JSON.stringify({ message: 'Username already exists' }),
      });
    }

    // Hash the password
    const hash = await bcrypt.hash(password, 10);

    // Create a new user
    const newUser = {
      user_id: Date.now().toString(),
      username,
      email,
      password: hash,
      created_at: Date.now(),
    };

    const putParams = {
      TableName: tableName,
      Item: newUser,
    };

    await dynamodb.put(putParams).promise();

    // After successfully saving the user, subscribe the user's email to the SNS topic
    const sns = new AWS.SNS();
    const topicArn = 'arn:aws:sns:us-east-1:875564694695:smCloudTerm'; // Replace with your SNS topic ARN

    const subscribeParams = {
      Protocol: 'email',
      TopicArn: topicArn,
      Endpoint: email, // User's email address
    };

    await sns.subscribe(subscribeParams).promise();

    return callback(null, {
      statusCode: 201,
      body: JSON.stringify({ message: 'User registered successfully' }),
    });
  } catch (error) {
    console.error('Error:', error);
    return callback(null, {
      statusCode: 500,
      body: JSON.stringify({ message: 'Server error' }),
    });
  }
};
