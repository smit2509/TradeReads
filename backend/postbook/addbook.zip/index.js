const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const sns = new AWS.SNS();

exports.handler = async (event) => {
  const body = JSON.parse(event.body);

  const { title, author, description, genre, year, owner } = body;

  const params = {
    TableName: 'books', // Replace with your table name
    Item: {
      book_id: uuidv4(), // Generate a unique ID for the book
      title,
      author,
      description,
      genre,
      release_year: year, // Update attribute name to release_year
      book_owner: owner, // Update attribute name to book_owner
      book_status: 'available', // Set initial status as available
      created_at: Date.now(),
    },
  };

  try {
    await dynamodb.put(params).promise();
    const arn = process.env.SNS_ARN;
    // Send a notification to all subscribers of the SNS topic
    const message = `New book added: ${title} by ${author}. Contact the owner at ${owner} for trading or take away. Happy Reading!!`;
    const publishParams = {
      Subject: 'New Book Alert',
      Message: message,
      TopicArn: arn, // Replace with your SNS topic ARN
    };

    await sns.publish(publishParams).promise();

    return {
      statusCode: 201,
      body: JSON.stringify({ message: 'Book created successfully' }),
    };
  } catch (error) {
    console.error('Error creating book:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Server error' }),
    };
  }
};
