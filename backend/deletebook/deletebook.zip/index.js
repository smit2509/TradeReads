const AWS = require('aws-sdk');

const dynamodb = new AWS.DynamoDB.DocumentClient();

const tableName = 'books'; // Update with your table name

exports.handler = async (event, context) => {
  const  bookId  = event.pathParameters.id;

  const params = {
    TableName: tableName,
    Key: { book_id: bookId },
  };

  try {
    await dynamodb.delete(params).promise();
    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Book deleted successfully' }),
    };
  } catch (error) {
    console.error('Error deleting book:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Server error' }),
    };
  }
};
